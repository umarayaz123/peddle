require File.dirname(__FILE__) + "/lib/blog_kit"

# Setup blog kit
BlogKit.instance